package com.lnt.loanApp.entities;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity(name="Customer")
@Table(name="customer_details")
public class Customer {
	@Column(name="name")
	private String name;
	@Id
	@Column(name="email")
	private String email;
	@Column(name="city")
	private String city;
	@Column(name="mobile")
	private String mobile;
	@Column(name="password")
	private String password;

	
public Customer() {}
		
public Customer(String name, String email, String city, String mobile, String password) {
		
		this.name = name;
		this.email = email;
		this.city = city;
		this.mobile = mobile;
		this.password = password;
	}

	public String getName() {     //name
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {      //email
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCity() {       //city
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getMobile() {   			//mobile
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getPassword() {       //password
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	@Override
	public String toString() {
		return "CustomerDetails [name=" + name + ", email=" + email + ", city=" + city + ", mobile=" + mobile
				+ ", password=" + password + "]";
	}
}

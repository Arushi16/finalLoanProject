package com.lnt.loanApp.entities; 

public class CustomerAccount {
	
	private String accountNumber;
	private String ifscCode ;
	private String bankName;
	private int salary;
	
	public CustomerAccount() {}
		
	public CustomerAccount(String accountNumber, String ifscCode, String bankName, int salary) {
		super();
		
		this.accountNumber = accountNumber;
		this.ifscCode = ifscCode;
		this.bankName = bankName;
		this.salary = salary;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	
	@Override
	public String toString() {
		return "CustomerAccount [accountNumber=" + accountNumber + ", ifscCode="
				+ ifscCode + ", bankName=" + bankName + ", salary=" + salary + "]";
	}
	
	
	
	
}
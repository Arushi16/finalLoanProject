var emicalculator = angular.module("app", []);
emicalculator.controller("emi", ['$scope', function ($scope) {
    var interestOnly = 0;
    var grandTotal = 0;
    var emi = 0;
    
    $scope.totalAmount = function () {
        var grandTotal = $scope.tenure * $scope.monthlyEmi();
        return grandTotal;
    };
    
    $scope.interestRate = function () {
    	interestOnly = Number($scope.totalAmount()) - Number($scope.principal);
        return interestOnly;
    }
    
    $scope.monthlyEmi = function () {
        ratePerMonth = $scope.interest_rate/(12*100);
        emi = $scope.principal * ratePerMonth * (Math.pow((1 + ratePerMonth), $scope.tenure)) / ((Math.pow((1 + ratePerMonth), $scope.tenure)) - 1);
        return emi;
    }
}]);